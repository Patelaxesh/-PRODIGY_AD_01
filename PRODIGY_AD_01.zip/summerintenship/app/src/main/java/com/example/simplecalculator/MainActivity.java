package com.example.simplecalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView tvInput;
    private String input = "";
    private String operator = "";
    private double value1 = Double.NaN;
    private double value2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvInput = findViewById(R.id.tvInput);

        setButtonListeners();
    }

    private void setButtonListeners() {
        int[] numberButtons = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
                R.id.btn8, R.id.btn9
        };

        for (int id : numberButtons) {
            findViewById(id).setOnClickListener(this::onNumberClick);
        }

        findViewById(R.id.btnAdd).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnSubtract).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnMultiply).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnDivide).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnEqual).setOnClickListener(this::onEqualClick);
        findViewById(R.id.btnClear).setOnClickListener(this::onClearClick);
    }

    private void onNumberClick(View view) {
        Button button = (Button) view;
        input += button.getText().toString();
        tvInput.setText(input);
    }

    private void onOperatorClick(View view) {
        if (!Double.isNaN(value1)) {
            value2 = Double.parseDouble(input);
            calculate();
            operator = ((Button) view).getText().toString();
            tvInput.setText(String.valueOf(value1) + operator);
            input = "";
        } else {
            value1 = Double.parseDouble(input);
            operator = ((Button) view).getText().toString();
            tvInput.setText(input + operator);
            input = "";
        }
    }

    private void onEqualClick(View view) {
        value2 = Double.parseDouble(input);
        calculate();
        tvInput.setText(String.valueOf(value1));
        input = "";
        value1 = Double.NaN;
        operator = "";
    }

    private void onClearClick(View view) {
        input = "";
        value1 = Double.NaN;
        value2 = Double.NaN;
        operator = "";
        tvInput.setText("");
    }

    private void calculate() {
        switch (operator) {
            case "+":
                value1 = value1 + value2;
                break;
            case "-":
                value1 = value1 - value2;
                break;
            case "*":
                value1 = value1 * value2;
                break;
            case "/":
                if (value2 != 0) {
                    value1 = value1 / value2;
                } else {
                    tvInput.setText("Error");
                }
                break;
        }
    }
}

